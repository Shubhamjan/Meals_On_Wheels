#Online_Food_Delivery_CDAC_Project
Tasty-Treat Online Food Delivery is a basic one stop web application for customers,hotel managers & delivery executives.Customers can order available food from  their favourite restaurants whereas the restaurants can decide which food from their restaurant is been made available for their customers under specific food categories. The restaurant managers can assign the food orders to the delivery executives and the delivery  executives can deliver the food order and notify about delivery status. J2EE (Spring Data JPA, Spring Boot) as back-end technology & React JS as a front-end technology with MySql database. 






First of all I would like to introduce about my project then after I will be telling the flow of my project.
My Project title is "Online Food Delivery" is a basic one stop web application for customers, restaurants manager & delivery executives.Customers can order available food from  their favourite restaurants whereas the restaurants can decide which food from their restaurant is been made available for their customers under specific food categories. The restaurant managers can assign the food orders to the delivery executives and the delivery  executives can deliver the food order and notify about delivery status. With the help of this system, people can easily order the food. It can also ensure that the people do not waste their precious time and use their time productively in the other works. In long run, this will ensure that it helps to reduce labour cost. This system proves to be more cost effective and reliable over other systems. J2EE (Spring Data JPA, Spring Boot) as back-end technology & React JS as a front-end technology with MySql database. 


The Online Food Delivery project aims to create a user friendly and efficient platform that facilitates the ordering and delivery of food from various restaurants or food establishments.The system will provide a convenient and seamless experience for customers to browse menus, place orders, make payments, and track the delivery status, all from the comfort of their own homes or offices.The online food delivery system is a WebBased full stack application that allows users to order food from restaurant and have it delivered. It aims to provide a convenient and efficient platform for users to browse menus, place orders, track delivery status.

This is web application Dashboard which consists of three modules Customer ,Restaurant Manager and Delivery. Each Module has  sign Up and Sing In functionality.
Customer will have to create account or register himself by proving EmailId and Password for placing the order.
Similarlly Restaurant Manager and Delivery Person have to do the same for thier tasts.
So the flow this web application Would be Customer will have to sign in and can order available food from  their favourite restaurants.
Now Order request will be available to the restaurant and The restaurant managers can assign the food orders to the delivery executives .
Then it will be notified to Delivery Person that their is request from This restaurant to this address.
then Delivery Executive will pickup the order and will about about the pickup status and also  
notify about delivery status.

Once the order is delivered the status will be updated to the restaurant Manager.
This is all about my project "Online Food Delivery" 







#Online Food Delivery
The project 'Online Food Delivery' is a basic one stop web application for customers,hotel managers & delivery executives.Customers can order available food from their favourite restaurants whereas the restaurants can decide which food from their restaurant is been made available for their customers under specific food categories. The restaurant managers can assign the food orders to the delivery executives and the delivery executives can deliver the food order and notify about delivery status. Java JEE (Spring Data JPA, Spring Boot) as back-end technology & React JS as a front-end technology with MySql database.



